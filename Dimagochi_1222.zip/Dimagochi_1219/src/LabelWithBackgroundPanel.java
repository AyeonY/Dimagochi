import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class LabelWithBackgroundPanel extends JPanel {
    private BufferedImage backgroundImage;
    private final JLabel textLabel;

    public LabelWithBackgroundPanel(String imageFileName, String labelText) {
        // 이미지를 로드합니다.
        try {
            backgroundImage = ImageIO.read(getClass().getResource(imageFileName));
        } 
        
        catch (IOException e) {
            System.err.println("배경 이미지 로드 실패: " + imageFileName);
            e.printStackTrace();
        }

        setLayout(new BorderLayout());
        setOpaque(false); // JPanel 기본 배경을 투명하게 설정 (이미지 배경이 보이도록)

        // 텍스트 레이블 생성 및 설정
        textLabel = new JLabel(labelText, SwingConstants.LEFT);
        textLabel.setFont(new Font("맑은 고딕", Font.BOLD, 12));
        textLabel.setForeground(Color.BLACK); // 텍스트 색상
        
        int leftPadding = 3;
        
        textLabel.setBorder(BorderFactory.createEmptyBorder(
            0,                 // 위 여백
            leftPadding,       // 왼쪽 여백
            0,                 // 아래 여백
            0                  // 오른쪽 여백
        ));
        
        add(textLabel, BorderLayout.WEST);
    }

@Override
protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    
    if (backgroundImage != null) {
        Graphics2D g2d = (Graphics2D) g;
        
        // int panelWidth = getWidth();
        // int panelHeight = getHeight();
        // g2d.drawImage(backgroundImage, 
        //               0, 0, panelWidth, panelHeight, 
        //               this);

        // 1. 이미지의 원본 너비와 높이를 가져옵니다.
        int imgWidth = backgroundImage.getWidth();
        int imgHeight = backgroundImage.getHeight();
        
        /*
        // ⭐ 옵션 A: 원본 크기 그대로 그림 (가장 간단) ⭐
        int drawWidth = imgWidth;
        int drawHeight = imgHeight;
        int drawX = 0; // 왼쪽 정렬
        */
        int panelHeight = getHeight();
        int drawHeight = panelHeight;
        // 비율 유지하며 너비 계산
        int drawWidth = (int) ((double) imgWidth * panelHeight / imgHeight);
        int drawX = 0; // 왼쪽 정렬
        
        g2d.drawImage(backgroundImage, 
                      drawX, 0, drawWidth, drawHeight, 
                      this);
    }
}
}