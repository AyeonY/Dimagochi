import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.util.Random;

public class EmoticonBubble extends JLabel {
    private Timer hideTimer;
    private Image bubbleImg;
    private final String[] emoticons = {"♥", "★", "♪", " >_< ", "G_G"};
    private final Random random = new Random();

    public EmoticonBubble() {
        // 1. 크기 설정 (기존 80x50 -> 60x40으로 축소)
        int width = 50;
        int height = 50;
        
        try {
            java.net.URL imgURL = getClass().getResource("/res/bubble.png");
            if (imgURL != null) {
                BufferedImage originalImg = ImageIO.read(imgURL);
                // 이미지를 설정한 크기에 딱 맞게 축소
                bubbleImg = originalImg.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            }
        } catch (IOException e) {
            System.err.println("말풍선 이미지 로드 실패");
        }

        setSize(width, height);
        setHorizontalAlignment(SwingConstants.CENTER);
        setVerticalAlignment(SwingConstants.CENTER);
        setOpaque(false);
        // 폰트 크기도 살짝 줄여서 밸런스를 맞춤
        setFont(new Font("맑은 고딕", Font.BOLD, 13)); 
        setVisible(false);

        hideTimer = new Timer(1500, e -> setVisible(false));
        hideTimer.setRepeats(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        // 배경 이미지 먼저 그리기
        if (bubbleImg != null) {
            g.drawImage(bubbleImg, 0, 0, this);
        }
        
        // --- 텍스트 위치 올리기 로직 ---
        // Graphics2D로 변환하여 정교하게 제어
        Graphics2D g2d = (Graphics2D) g.create();
        // y 좌표를 -4만큼 이동 (위로 올림). 이미지 모양에 따라 -2 ~ -6 사이로 조절해보세요.
        g2d.translate(0, -4); 
        super.paintComponent(g2d); 
        g2d.dispose();
    }

    public void showAt(int x, int y, int charWidth) {
        setText(emoticons[random.nextInt(emoticons.length)]);
        updatePosition(x, y, charWidth);
        setVisible(true);
        if (hideTimer.isRunning()) hideTimer.stop();
        hideTimer.start();
    }

    public void updatePosition(int x, int y, int charWidth) {
        // 말풍선이 작아졌으므로 위치 계산을 다시 맞춤
        int bx = x + (charWidth / 2) - (getWidth() / 2);
        // 캐릭터 머리에 더 가깝게 붙이고 싶으면 -30 정도로 조절
        int by = y - 35; 
        setLocation(bx, by);
    }
}