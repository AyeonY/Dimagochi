import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;
import java.util.Random;

public class MiniGameDialog extends JDialog {
    private Dimagotchi pet;
    private JLabel infoLabel;
    private Random random = new Random();
    
    private Timer gameTimer, fireTimer, explodeTimer, targetMoveTimer, enemyFireTimer, countDownTimer;    

    private int missileHits = 0;         
    private int remainingShots = 0;      
    private int feedingRound = 0;     
    private int timeLeft = 50;        
    
    private int score = 0;
    private int missed = 0;
    private Point[] heartPos = new Point[3];
    private int[] heartSpeeds = new int[3];

    private boolean isFiring = false;    
    private boolean isExploding = false; 
    private Point targetPos = new Point(180, 50); 
    private Point shipPos = new Point(225, 420);  
    private Point enemyBulletPos = null; 
    private int targetDirection = 1; 
    private int targetSpeed = 7;     

    private BufferedImage[] enemyImages = new BufferedImage[3]; 
    private BufferedImage[] foodImages = new BufferedImage[5]; 
    private String[] foodFiles = {"grape.png", "orange.png", "cherry.png", "apple.png", "lemon.png"};
    private int targetFoodIndex = 0; 
    private BufferedImage shipImage, heartImage, appleImage; 

    private JPanel gameCanvas; 
    private KeyListener gameKeyListener;
    private Point dragPoint = null;
    private int draggingFoodIndex = -1;
    
    private int missileLives = 3;
    private boolean isShipExploding = false;

    public MiniGameDialog(JFrame owner, Dimagotchi pet) {
        super(owner, "미니게임!", true);
        
        this.pet = pet;
        setSize(450, 650); 
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        loadImages();
        showMenu();
    }

    private void loadImages() {
        shipImage = loadImageFile("/ufo.png");
        heartImage = loadImageFile("/heart.png");
        appleImage = loadImageFile("/apple.png"); 
        enemyImages[0] = loadImageFile("/alien.png");
        enemyImages[1] = loadImageFile("/alien2.png");
        enemyImages[2] = loadImageFile("/alien3.png");
        
        for (int i = 0; i < foodFiles.length; i++) {
            foodImages[i] = loadImageFile("/" + foodFiles[i]);
        }
    }

    private BufferedImage loadImageFile(String path) {
        try {
            InputStream is = getClass().getResourceAsStream(path);
            if (is == null) is = getClass().getResourceAsStream("/res" + path);
            if (is != null) return ImageIO.read(is);
        } 
        
        catch (IOException e) {
            System.err.println(path + " 로딩 실패");
        }
        
        return null;
    }

    private void showMenu() {
        stopAllTimers();
        
        if (gameKeyListener != null) {
            removeKeyListener(gameKeyListener);
            gameKeyListener = null;
        }
        
        getContentPane().removeAll();
        getContentPane().setBackground(Color.WHITE);

        infoLabel = new JLabel("어떤 게임을 할까요?", SwingConstants.CENTER);
        infoLabel.setFont(new Font("맑은 고딕", Font.BOLD, 22));
        infoLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        add(infoLabel, BorderLayout.NORTH);

        JPanel menuPanel = new JPanel(new GridLayout(1, 3, 20, 0));
        menuPanel.setBackground(Color.WHITE);
        menuPanel.setBorder(BorderFactory.createEmptyBorder(30, 20, 30, 20));

        menuPanel.add(createIconButton(shipImage, "외계인 격추", 80, e -> startMissileGame()));
        menuPanel.add(createIconButton(appleImage, "밥 주기", 80, e -> startFeedingGame()));
        menuPanel.add(createIconButton(heartImage, "하트 받기", 60, e -> startHeartGame()));

        add(menuPanel, BorderLayout.CENTER);

        JPanel helpPanel = new JPanel(new GridLayout(4, 1));
        helpPanel.setBackground(new Color(245, 245, 245));
        helpPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        
        JLabel h1 = new JLabel(" [ 조작 방법 ] ", SwingConstants.CENTER);
        h1.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        
        JLabel h2 = new JLabel("• 외계인 격추: A/D로 이동, SPACE로 레이저 발사", SwingConstants.LEFT);
        JLabel h3 = new JLabel("• 밥 주기: 마우스 드래그로 입에 넣기", SwingConstants.LEFT);
        JLabel h4 = new JLabel("• 하트 받기: 마우스 이동으로 캐릭터 조작", SwingConstants.LEFT);
        
        Font helpFont = new Font("맑은 고딕", Font.PLAIN, 12);
        h2.setFont(helpFont); h3.setFont(helpFont); h4.setFont(helpFont);
        
        helpPanel.add(h1); helpPanel.add(h2); helpPanel.add(h3); helpPanel.add(h4);
        add(helpPanel, BorderLayout.SOUTH);

        revalidate();
        repaint();
    }

    private JButton createIconButton(BufferedImage img, String title, int size, java.awt.event.ActionListener listener) {
        JButton button = new JButton();
        
        if (img != null) {
            Image scaledImg = img.getScaledInstance(size, size, Image.SCALE_SMOOTH);
            button.setIcon(new ImageIcon(scaledImg));
        } 
        
        else {
            button.setText(title);
        }
        
        button.setToolTipText(title);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(listener);

        button.addMouseListener(new MouseAdapter() {
            @Override 
            public void mouseEntered(MouseEvent e) { 
            	button.setContentAreaFilled(true);
            	button.setBackground(new Color(230, 230, 250)); 
            	}
            
            @Override 
            public void mouseExited(MouseEvent e) { 
            	button.setContentAreaFilled(false); 
            	}
        });
        
        return button;
    }

    private void startHeartGame() {
        getContentPane().removeAll();
        score = 0; missed = 0; shipPos.x = 225;
        
        for (int i = 0; i < heartPos.length; i++) {
            heartPos[i] = new Point(random.nextInt(380) + 20, -random.nextInt(400));
            heartSpeeds[i] = 5 + random.nextInt(6);
        }

        gameCanvas = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 240, 245)); g2.fillRect(0, 0, getWidth(), getHeight());
                
                Image petImg = (pet.getCharacter() != null) ? pet.getCharacter().getCurrentImage() : null;
                
                if (petImg != null) g2.drawImage(petImg, shipPos.x - 50, 450, 100, 100, this);
                
                for (Point p : heartPos) if (heartImage != null) g2.drawImage(heartImage, p.x, p.y, 25, 25, this);
                
                g2.setColor(Color.BLACK); 
                g2.setFont(new Font("맑은 고딕", Font.BOLD, 16));
                g2.drawString("점수: " + score + " / 10 | 놓친 개수: " + missed + "/5", 20, 40);
            }
        };

        gameCanvas.addMouseMotionListener(new MouseAdapter() {
            @Override 
            public void mouseMoved(MouseEvent e) { 
            	shipPos.x = e.getX(); gameCanvas.repaint(); 
            	}
        });

        gameTimer = new Timer(30, e -> {
            for (int i = 0; i < heartPos.length; i++) {
                heartPos[i].y += heartSpeeds[i];

                Rectangle petHitBox = new Rectangle(shipPos.x - 15, 470, 30, 50); 
                Rectangle heartHitBox = new Rectangle(heartPos[i].x + 2, heartPos[i].y + 2, 20, 20);

                if (petHitBox.intersects(heartHitBox)) {
                    score++; 
                    resetHeart(i);
                    
                    gameCanvas.repaint();

                    if (score >= 10) {
                        gameTimer.stop();

                        Timer delayTimer = new Timer(100, ev -> endGame("하트를 받아 행복해졌어요!", true));
                        
                        delayTimer.setRepeats(false);
                        delayTimer.start();
                        
                        return; 
                    }
                }

                if (heartPos[i].y > getHeight()) { 
                    missed++; 
                    resetHeart(i); 
                    
                    if (missed >= 5) { 
                        gameTimer.stop(); 
                        
                        endGame("하트를 너무 많이 놓쳤어요...", false); 
                        
                        return;
                    }
                }
            }
            
            gameCanvas.repaint();
        });
        
        gameTimer.start();
        add(gameCanvas, BorderLayout.CENTER);
        
        revalidate(); repaint();
    }

    private void resetHeart(int index) {
        heartPos[index].x = random.nextInt(380) + 10;
        heartPos[index].y = -50;
    }

    private void startFeedingGame() {
        getContentPane().removeAll();
        feedingRound = 1;
        startNewFeedingRound();
    }

    private void startNewFeedingRound() {
        timeLeft = 50; 
        targetFoodIndex = random.nextInt(5);
        draggingFoodIndex = -1; dragPoint = null;
        
        gameCanvas = new JPanel() {
            @Override 
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(240, 255, 240)); g2.fillRect(0, 0, getWidth(), getHeight());

                int barMaxWidth = 300;           
                int barHeight = 15;              
                int barX = (getWidth() - barMaxWidth) / 2; 
                int barY = 45;                   

                g2.setColor(new Color(200, 200, 200));
                g2.fillRoundRect(barX, barY, barMaxWidth, barHeight, 10, 10);

                int currentBarWidth = (int) ((timeLeft / 50.0) * barMaxWidth);
                if (timeLeft > 20) g2.setColor(new Color(100, 255, 100)); 
                else g2.setColor(new Color(255, 100, 100));              
                
                g2.fillRoundRect(barX, barY, currentBarWidth, barHeight, 10, 10);
                g2.setColor(Color.BLACK);
                g2.drawRoundRect(barX, barY, barMaxWidth, barHeight, 10, 10);

                Image petImg = (pet.getCharacter() != null) ? pet.getCharacter().getCurrentImage() : null;
                if (petImg != null) g2.drawImage(petImg, getWidth()/2 - 60, getHeight()/2 - 80, 120, 120, this);
                
                g2.setColor(Color.WHITE); g2.fillRoundRect(getWidth()/2 + 40, getHeight()/2 - 100, 50, 50, 15, 15);
                if (foodImages[targetFoodIndex] != null) g2.drawImage(foodImages[targetFoodIndex], getWidth()/2 + 50, getHeight()/2 - 90, 30, 30, this);
                
                for (int i = 0; i < 5; i++) {
                    if (foodImages[i] != null && i != draggingFoodIndex) g2.drawImage(foodImages[i], 50 + (i * 70), 450, 50, 50, this);
                }
                
                if (draggingFoodIndex != -1 && dragPoint != null) g2.drawImage(foodImages[draggingFoodIndex], dragPoint.x - 25, dragPoint.y - 25, 60, 60, this);
                
                g2.setColor(Color.BLACK); 
                g2.setFont(new Font("맑은 고딕", Font.BOLD, 16));
                g2.drawString("Round: " + feedingRound + " / 3", 20, 30); 
                g2.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
                g2.drawString("조작: 원하는 음식을 드래그해서 입으로 옮기세요", 20, 80);
            }
        };

        MouseAdapter ma = new MouseAdapter() {
            @Override 
            public void mousePressed(MouseEvent e) {
                for (int i = 0; i < 5; i++) 
                	if (new Rectangle(50 + (i * 70), 450, 50, 50).contains(e.getPoint())) { 
                	draggingFoodIndex = i; dragPoint = e.getPoint(); break; 
                	}
            }
            
            @Override 
            public void mouseDragged(MouseEvent e) { if (draggingFoodIndex != -1) { 
            	dragPoint = e.getPoint(); gameCanvas.repaint(); } 
            }
            
            @Override 
            public void mouseReleased(MouseEvent e) {
                if (draggingFoodIndex != -1) {
                    if (new Rectangle(getWidth()/2 - 60, getHeight()/2 - 80, 120, 120).contains(e.getPoint())) {
                        if (draggingFoodIndex == targetFoodIndex) handleSuccess();
                        
                        
                        else { draggingFoodIndex = -1; dragPoint = null; }
                    } 
                    
                    else { draggingFoodIndex = -1; dragPoint = null; }
                    
                    gameCanvas.repaint();
                }
            }
        };
        
        gameCanvas.addMouseListener(ma); gameCanvas.addMouseMotionListener(ma);
        
        if (countDownTimer != null) countDownTimer.stop();
        
        countDownTimer = new Timer(100, e -> {
            timeLeft--; 
            
            if (timeLeft <= 0) { 
                countDownTimer.stop(); 
                JOptionPane.showMessageDialog(this, "시간 초과!"); 
                
                showMenu(); 
            }
            
            gameCanvas.repaint();
        });
        
        countDownTimer.start();
        
        getContentPane().removeAll(); add(gameCanvas, BorderLayout.CENTER);
        revalidate(); repaint();
    }

    private void handleSuccess() {
        countDownTimer.stop();
        
        if (feedingRound >= 3) { endGame("정말 맛있는 식사였어요!", true); }
        else { feedingRound++; startNewFeedingRound(); }
    }

    private void startMissileGame() {
        getContentPane().removeAll();
        missileHits = 0; 
        remainingShots = 10; 
        missileLives = 3; 
        targetSpeed = 7;
        isFiring = false; 
        isExploding = false; 
        isShipExploding = false;
        enemyBulletPos = null;
        
        shipPos.setLocation(225, 420); 
        targetPos.setLocation(180, 50);

        gameCanvas = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                
                Graphics2D g2 = (Graphics2D) g;
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(5, 5, 25)); g2.fillRect(0, 0, getWidth(), getHeight());
                
                if (isShipExploding) {
                    g2.setFont(new Font("Serif", Font.PLAIN, 50)); 
                    g2.drawString("💥", shipPos.x - 25, shipPos.y + 15);
                } 
                
                else {
                    if (shipImage != null) g2.drawImage(shipImage, shipPos.x - 30, shipPos.y - 30, 60, 60, this);
                }
                
                if (isFiring) { 
                    g2.setColor(Color.GREEN); 
                    g2.setStroke(new BasicStroke(3f)); 
                    g2.drawLine(shipPos.x, shipPos.y - 30, shipPos.x, 0); 
                }
                
                if (enemyBulletPos != null) { 
                    g2.setColor(Color.RED); 
                    g2.fillOval(enemyBulletPos.x - 5, enemyBulletPos.y, 10, 20); 
                }
                
                if (isExploding) {
                    g2.setFont(new Font("Serif", Font.PLAIN, 40)); 
                    g2.drawString("💥", targetPos.x, targetPos.y + 45);
                } 
                
                else {
                    int idx = Math.min(missileHits, 2);
                    if (enemyImages[idx] != null) g2.drawImage(enemyImages[idx], targetPos.x, targetPos.y, 60, 60, this);
                }

                g2.setFont(new Font("맑은 고딕", Font.BOLD, 15));
                g2.setColor(Color.WHITE);
                g2.drawString(String.format("격추: %d / 3 | 탄환: %d | 목숨: %d", missileHits, remainingShots, missileLives), 20, 30);
            }
        };

        targetMoveTimer = new Timer(30, e -> {
            if (!isExploding && !isShipExploding) {
                targetPos.x += (targetDirection * targetSpeed);
                
                if (targetPos.x <= 0 || targetPos.x >= getWidth() - 60) targetDirection *= -1;
                
                if (enemyBulletPos != null) {
                    enemyBulletPos.y += 8;
                    
                    if (new Rectangle(shipPos.x - 25, shipPos.y - 25, 50, 50).contains(enemyBulletPos)) {
                        handleShipHit();
                    } 
                    
                    else if (enemyBulletPos.y > getHeight()) {
                        enemyBulletPos = null;
                    }
                }
            }
            
            gameCanvas.repaint();
        });

        enemyFireTimer = new Timer(1200, e -> {
            if (!isExploding && !isShipExploding && enemyBulletPos == null && random.nextInt(10) > 3) 
                enemyBulletPos = new Point(targetPos.x + 30, targetPos.y + 60);
        });

        gameKeyListener = new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (isShipExploding) return;
                if (e.getKeyCode() == KeyEvent.VK_A) shipPos.x = Math.max(30, shipPos.x - 25);
                if (e.getKeyCode() == KeyEvent.VK_D) shipPos.x = Math.min(getWidth() - 30, shipPos.x + 25);
                if (e.getKeyCode() == KeyEvent.VK_SPACE && !isFiring && !isExploding && remainingShots > 0) { 
                    remainingShots--; 
                    triggerSequence(); 
                }
                
                gameCanvas.repaint();
            }
        };

        this.addKeyListener(gameKeyListener);
        add(gameCanvas, BorderLayout.CENTER);
        
        targetMoveTimer.start();
        enemyFireTimer.start();
        
        revalidate(); repaint();
        this.requestFocusInWindow();
    }

    private void handleShipHit() {
        isShipExploding = true;
        enemyBulletPos = null;
        
        missileLives--;

        Timer shipExplodeTimer = new Timer(600, e -> {
            isShipExploding = false;
            
            if (missileLives <= 0) {
                endGame("지구가 침공당했습니다!", false);
            } 
            
            else {
                shipPos.x = getWidth() / 2;
            }
            
            ((Timer)e.getSource()).stop();
        });
        
        shipExplodeTimer.start();
    }

    private void triggerSequence() {
        isFiring = true;
        boolean isHit = Math.abs(shipPos.x - (targetPos.x + 30)) < 40;
        
        fireTimer = new Timer(150, e -> {
            isFiring = false;
            
            if (isHit) {
                isExploding = true;
                
                explodeTimer = new Timer(400, e2 -> {
                    isExploding = false; missileHits++;
                    
                    if (missileHits >= 3) endGame("지구를 구했습니다!", true);
                    else { targetSpeed += 4; targetPos.x = random.nextInt(300); }
                });
                
                explodeTimer.setRepeats(false); explodeTimer.start();
            }
            
            if (remainingShots <= 0 && !isHit && missileHits < 3) endGame("탄환을 모두 소모했습니다.", false);
            gameCanvas.repaint();
        });
        
        fireTimer.setRepeats(false); fireTimer.start();
    }

    private void endGame(String msg, boolean isVictory) {
        stopAllTimers();
        
        String rewardMsg = msg;
        
        if (isVictory) {
            rewardMsg += "\n음식과 코인을 얻었습니다!";
            pet.addFood(2); 
            pet.addCoins(5);
        }

        JOptionPane.showMessageDialog(this, rewardMsg);
        showMenu();
    }
    
    private void stopAllTimers() {
        if (gameTimer != null) gameTimer.stop();
        if (fireTimer != null) fireTimer.stop();
        if (explodeTimer != null) explodeTimer.stop();
        if (targetMoveTimer != null) targetMoveTimer.stop();
        if (countDownTimer != null) countDownTimer.stop();
        if (enemyFireTimer != null) enemyFireTimer.stop();
    }
}