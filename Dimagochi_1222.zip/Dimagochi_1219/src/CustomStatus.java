public class CustomStatus {
	public int width;       
	public int height;      
	public int start_x;     
	public int start_y;     
	public int frame_size;  
}