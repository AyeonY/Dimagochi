import java.util.Random;

public class Dimagotchi {
    private String name;
    
    private int hunger;
    private int happiness;
    private int energy;
    public static String causeOfDeath;//왜 죽었는지 저장. 
    private int count;// 진화를 위한 행동 카운텨.
    private boolean isEvolved;  // 진화 여부 필드 추가
    private String evolutionMessage; // 진화 메시지 필드 추가
    
    private int feedCount;
    private int playCount;
    private int sleepCount;
    private int cleanCount; 
    
    private int evolLevel=0; 
    
    private int coins; 
    
    private int cleanliness; // 청결도 (0~100)
    private int flyCount; // 현재 있는 벌레 수
    
    private Character character;
    
    public Dimagotchi(String name) {
        this.name = name;
        this.hunger = 50;
        this.happiness = 50;
        this.energy = 100;
        this.causeOfDeath ="";
        this.count = 0;
        this.isEvolved = false; 
        this.evolutionMessage = ""; 
        
        this.feedCount = 0;
        this.playCount = 0;
        this.sleepCount = 0;
        this.cleanCount = 0; 
        
        this.coins = 0; //  초기 코인 0개로 시작
        this.cleanliness = 100;
        
     // Character 객체 초기화 (DimagotchiGUI의 화면 크기 800x500 고려)
        this.character = new Character(350, 300);
        
    }

    private int foodCount = 3; // 초기 먹이 개수 3개
    
    public int getFoodCount() { return foodCount; }
    public void addFood(int amount) { this.foodCount += amount; }
    
    public String feed() {
        if (!causeOfDeath.isEmpty()) return "다마고치가 밥을 먹지 않습니다....";
        if (foodCount <= 0) return "먹이가 부족합니다! TV 미니게임을 플레이하세요.";

        // 1. 시간 경과(패널티)를 먼저 적용
        passTime(); 

        // 2. 그 다음 회복 적용 (이제 0까지 내려가서 포만감 100 가능)
        this.foodCount--;
        this.hunger = Math.max(0, hunger - 20);
        this.energy = Math.min(100, energy + 5); 
        this.feedCount++;
        
        return "냠냠! 밥을 먹었습니다. (남은 먹이: " + foodCount + "개)";
    }

    public String play() {
        if (!causeOfDeath.isEmpty()) return "반응이 없습니다...";
        if (energy < 20) {
            System.out.println("너무 피곤해서 놀 수 없어요.");
            return "너무 피곤해서 놀 수 없어요.";
        }
        System.out.println("energy:"+energy);
        this.happiness = Math.min(100, happiness + 15);
        this.energy = Math.max(0, energy - 20);
        System.out.println("energy:"+energy);
        
        System.out.println(hunger);
        this.hunger = Math.min(100, hunger + 10); 
        this.playCount++;
        passTime();
        
        System.out.println("신나게 놀았습니다!");
        return "신나게 놀았습니다!";
    }

    public String sleep() {
        if (!causeOfDeath.isEmpty()) return "영원히 잠들었습니다...";
        this.energy =  Math.min(100, energy +20);
        passTime();
        
        this.sleepCount++;
        System.out.println("쿨쿨... 잠을 자고 에너지를 채웠습니다.");
        return "쿨쿨... 잠을 자고 에너지를 채웠습니다.";
    }
    
    // 💡 [추가] 청소하기 메서드
    public String clean() {
        if (!causeOfDeath.isEmpty()) return "반응이 없습니다...";
        
        // 1. 시간 경과 먼저 적용
        passTime();

        // 2. 청결도 회복 적용
        this.happiness = Math.min(100, happiness + 10);
        this.energy = Math.max(0, energy - 10);
        this.cleanliness = 100; // 이제 100으로 유지됨
        this.cleanCount++;
        
        return "쓱싹쓱싹! 깨끗하게 청소했습니다.";
    }

    private void passTime() {
        this.count++;
        
        // 포만감 수치 조절 (hunger가 늘어나야 GUI에서 fullness(100-hunger)가 줄어듬)
        this.hunger = Math.min(100, this.hunger + 5); 
        this.happiness = Math.max(0, this.happiness - 5);
        this.cleanliness = Math.max(0, this.cleanliness - 2);

        if (flyCount > 0) {
            this.cleanliness = Math.max(0, this.cleanliness - (flyCount * 2)); 
        }
        
        checkStatus();
        checkEvolution(); // 여기서 count 관리가 중요함
    }

    private void checkStatus() {
    	if(causeOfDeath.isEmpty()) {
    		//hunger가 100이넘고, happiness가 0으로 되면 
        	// 아사 조건 변경
        	if(hunger>=100) { 
        		Dimagotchi.causeOfDeath ="사망원인: 아사";
        	}
        	else if(happiness<=0){
        		Dimagotchi.causeOfDeath ="사망원인: 고독사";
        	}
        	// 탈진사 조건 추가
        	else if(energy<=0){ 
        		Dimagotchi.causeOfDeath ="사망원인: 탈진사";
        	}
    	}
    }
    
    public static boolean isAliveStatic() {
        return causeOfDeath.isEmpty();
    }
    
    private void checkEvolution() {
        // [수정] 이미 최종 진화(2단계)인 경우에도 count를 초기화해주어야 
        // 내부 로직이 꼬이지 않고 다음 동작들이 정상 수행됩니다.
        if (count >= 8 && Dimagotchi.isAliveStatic()) {
            if (evolLevel < 2) {
                evolLevel++;
                character.evolve(this, happiness, evolLevel); 
                evolutionMessage = name + "이(가) " + evolLevel + "단계로 성장했습니다!";
                
                // 진화 시에만 초기화하던 카운트들을 밖으로 뺍니다.
                this.feedCount = 0;
                this.playCount = 0;
                this.sleepCount = 0;
                this.cleanCount = 0;
            }
            // 최종 진화 후에도 카운트는 계속 리셋해주어야 시스템 부하를 막고 로직이 유지됨
            this.count = 0; 
        }
    }
    public void printStatus() {
    	String moodFace ="";
        System.out.println("\n-------------------------");
        System.out.println(" 이름: " + name + " " + moodFace);
        System.out.println(" 배고픔: " + drawBar(hunger, false));
        System.out.println(" 행복도: " + drawBar(happiness, false));
        System.out.println(" 에너지: " + drawBar(energy, false));
        System.out.println(" 청결도: " + drawBar(cleanliness, false));
        System.out.println("-------------------------");
    }

    //시각적으로 텍스트 막대로 변화해 콘솔에 추가하기 위해서
    private String drawBar(int value, boolean isBadStat) {
        StringBuilder bar = new StringBuilder("[");
        int count = value / 10; 
        for (int i = 0; i < 10; i++) {
            if (i < count) bar.append(isBadStat ? "■" : "■"); 
            else bar.append(" ");
        }
        bar.append("] " + value);
        return bar.toString();
    }

    
    public Character getCharacter() { return character; }
    public int getXPos() { return character.getXPos(); }
    public int getYPos() { return character.getYPos(); }
    
    public int getFeedCount() { return feedCount; }
    public int getPlayCount() { return playCount; }
    public int getSleepCount() { return sleepCount; }
    public int getCleanCount() { return cleanCount; }
    
    public int getHunger() { return hunger; }
    public int getHappiness() { return happiness; }
    public int getEnergy() { return energy; }

    //public boolean isAlive() { return isAlive; }
    public String getName() { return name; }
    
    public String getCauseOfDeath() { return causeOfDeath;}// 왜 죽었는지 원인 출력. 
    
    public String getEvolutionMessage() { return evolutionMessage; }
    public void resetEvolutionMessage() { this.evolutionMessage = ""; }
    
    // 코인 관련 메서드
    public int getCoins() { return coins; }
    
    public boolean spendCoins(int amount) {
        if (coins >= amount) {
            coins -= amount;
            return true;
        }
        return false;
    }
    
    public void addCoins(int amount) {
        coins += amount;
}
    
    // 벌레 및 청결도 관련 메서드
    public int getCleanliness() { return cleanliness; }
    
    public void addFly() {
        this.flyCount++;
        
        // 벌레가 늘어나면 청결도가 즉시 조금 깎임
        this.cleanliness = Math.max(0, cleanliness - 5);
    }
    
    public String catchFly() {
        if (flyCount > 0) {
            flyCount--;
            
            // cleanliness = Math.min(100, cleanliness + 5); 
            
            addCoins(5); // 코인 획득은 그대로 유지
            return "벌레를 잡았다! (5G 획득)";
        }
        return "";
    }
    
    public void resetAll() {
        Dimagotchi.causeOfDeath = ""; 
        
        this.hunger = 50;
        this.happiness = 50;
        this.energy = 100;
        this.cleanliness = 100;
        
        this.evolLevel = 0;
        this.count = 0;
        this.feedCount = 0;
        this.playCount = 0;
        this.sleepCount = 0;
        this.cleanCount = 0;

        if (this.character != null) {
            this.character.resetCharacter(); 
        }
    }
    
    public int getFlyCount() { return flyCount; }
	public void setFoodCount(int i) {
		// TODO Auto-generated method stub
	}

}