import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

public class ShopDialog extends JDialog {
    private final Consumer<furniture.FurnitureType> onItemSelected;
    private Dimagotchi pet; // 펫 객체 참조 추가

    public ShopDialog(JFrame owner, Dimagotchi pet, Consumer<furniture.FurnitureType> callback) {
        super(owner, "다마고치 가구 상점", true);
        this.pet = pet; // 펫 데이터 연결
        this.onItemSelected = callback;

        setSize(600, 450);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        initUI();
    }

    private void initUI() {
        // 상단 안내 메시지
        JLabel title = new JLabel("가구를 선택하세요", SwingConstants.CENTER);
        title.setFont(new Font("맑은 고딕", Font.BOLD, 18));
        title.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        add(title, BorderLayout.NORTH);

        // 아이템 리스트 패널 (그리드 레이아웃)
        JPanel shopPanel = new JPanel();
        shopPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 25, 25));
        shopPanel.setBackground(new Color(250, 250, 250));

        // 모든 가구 타입에 대해 카드 생성
        for (furniture.FurnitureType type : furniture.FurnitureType.values()) {
            shopPanel.add(createItemCard(type));
        }

        JScrollPane scrollPane = new JScrollPane(shopPanel);
        scrollPane.setBorder(null);
        add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel createItemCard(furniture.FurnitureType type) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        // 1. 가구 미리보기
        furniture tempFurn = new furniture(type, 0, 0);
        Image previewImg = tempFurn.getScaledImage(2);
        JLabel imgLabel = new JLabel(new ImageIcon(previewImg));
        imgLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 2. 가구 이름 및 가격 표시
        String displayName = getDisplayName(type);
        JLabel nameLabel = new JLabel(displayName);
        nameLabel.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel priceLabel = new JLabel(type.getPrice() + " G"); // 가격 표시
        priceLabel.setFont(new Font("맑은 고딕", Font.BOLD, 13));
        priceLabel.setForeground(new Color(184, 134, 11)); // 금색 계열
        priceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 3. 구매 버튼
        JButton buyBtn = new JButton("구매하기");
        buyBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // 보유 금액에 따른 버튼 활성화/비활성화 시각적 효과
        if (pet.getCoins() < type.getPrice()) {
            buyBtn.setText("잔액 부족");
            buyBtn.setEnabled(false);
        }

        buyBtn.addActionListener(e -> {
            // 최종 금액 확인 및 차감
            if (pet.spendCoins(type.getPrice())) {
                onItemSelected.accept(type);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "코인이 부족합니다!", "구매 실패", JOptionPane.WARNING_MESSAGE);
            }
        });

        card.add(imgLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(nameLabel);
        card.add(priceLabel); // 가격 레이블 추가
        card.add(Box.createVerticalStrut(10));
        card.add(buyBtn);

        return card;
    }

    private String getDisplayName(furniture.FurnitureType type) {
        // Enum 이름을 한글로 변환 (필요에 따라 수정)
        switch (type) {
            case FLOWER_POT: return "넓은 나뭇잎 화분";
            case FLOWER_POT2: return "얇은 나뭇잎 화분";
            case FLOWER_POT3: return "우유병 화분";
            case FLOWER_POT4: return "처진 나뭇잎 화분";
            case FLOWER_POT5: return "꽃 화분";
         
            case BOOKCASE1: return "화분이 있는 책장";
            case BOOKCASE2: return "책이 있는 책장";
            
            case SHELF: return "벽걸이 선반";
            case TABLE: return "책상";
            case SMALLSHELF: return "작은 선반";
            case THINSHELF: return "좁은 선반";
            case TABLE2: return "화분 테이블";
          
            
 
            default: return type.name();
        }
    }
}