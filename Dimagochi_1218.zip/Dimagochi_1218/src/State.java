/**
 * State.java
 * 스프라이트 시트 내에서 특정 자세/애니메이션 프레임의 영역 정보를 저장합니다.
 */
public class State {
    // 스프라이트 시트 내에서 자세의 시작 X 좌표
    public int start_x;
    // 스프라이트 시트 내에서 자세의 시작 Y 좌표
    public int start_y; 
    // 개별 프레임의 너비
    public int width;
    // 개별 프레임의 높이
    public int height;
    
    
    
    // 애니메이션을 구성하는 프레임의 개수 (정지 모션은 1)
    public int frame_size; 
    // 👈 [추가!] 현재 표시할 프레임 인덱스
    public int index = 0;   
    
    // 이 자세가 어떤 이미지 파일과 연결되는지 (예: dog_atlas.png)
    public String image_path; 
    
    
}