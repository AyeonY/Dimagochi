public class CustomStatus {

	// 이제 사용자님이 원하셨던 State의 멤버 변수들을 넣습니다.
	public int width;       
	public int height;      
	public int start_x;     
	public int start_y;     
	public int frame_size;  
	// 이 클래스 내부에 public static class State를 다시 넣으면 안 됩니다!
}